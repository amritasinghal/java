package strongsync;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseHelper {
    // ✅ Change these as per your setup
    private static final String URL = "jdbc:mysql://localhost:3306/strongsync";
    private static final String USER = "root";
    private static final String PASSWORD = "Drowssap8979."; // change this

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void saveBMI(String username, double bmi, String category, String suggestion) {
        String sql = "INSERT INTO bmi_records (username, bmi, category, suggestion) VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setDouble(2, bmi);
            stmt.setString(3, category);
            stmt.setString(4, suggestion);

            stmt.executeUpdate();
            System.out.println("✅ BMI data saved successfully!");

        } catch (SQLException e) {
            System.out.println("❌ Failed to save BMI data.");
            e.printStackTrace();
        }
    }
}
