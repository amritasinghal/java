package strongsync;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class WorkoutPlanGUI extends JFrame {
    private final Map<String, String> workoutDetails = new HashMap<>();
    private JTextArea detailArea;
    private String selectedPlanName = "";
    private final String username;

    public WorkoutPlanGUI(String username) {
        this.username = username;

        setTitle("Workout Plans - " + username);
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Header
        JLabel header = new JLabel("Choose a Workout Plan");
        header.setFont(new Font("Arial", Font.BOLD, 20));
        header.setHorizontalAlignment(SwingConstants.CENTER);
        header.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(header, BorderLayout.NORTH);

        // Populate workout details
        setupWorkoutPlans();

        // Workout options panel
        JPanel optionsPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        optionsPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        for (String plan : workoutDetails.keySet()) {
            JButton btn = new JButton(plan);
            styleButton(btn);
            btn.addActionListener(e -> showWorkoutDetails(plan));
            optionsPanel.add(btn);
        }

        // Text area for workout instructions
        detailArea = new JTextArea(12, 30);
        detailArea.setLineWrap(true);
        detailArea.setWrapStyleWord(true);
        detailArea.setEditable(false);
        detailArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(detailArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Workout Routine"));
        add(optionsPanel, BorderLayout.WEST);
        add(scrollPane, BorderLayout.CENTER);

        // Save and Back buttons
        JButton saveButton = new JButton("💾 Save This Plan");
        saveButton.setFont(new Font("Arial", Font.BOLD, 14));
        saveButton.addActionListener(e -> saveSelectedPlan());

        JButton backButton = new JButton("⬅ Back to Dashboard");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.addActionListener(e -> {
            dispose();
            new DashboardGUI(username);
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(saveButton);
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void showWorkoutDetails(String planName) {
        selectedPlanName = planName;
        detailArea.setText(workoutDetails.get(planName));
    }

    private void saveSelectedPlan() {
        if (selectedPlanName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠ Please select a workout plan first.", "No Plan Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        boolean success = saveWorkoutToDB(username, selectedPlanName);

        if (success) {
            JOptionPane.showMessageDialog(this, "✅ Workout plan saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "❌ Failed to save the workout plan.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean saveWorkoutToDB(String username, String planName) {
        String sql = "INSERT INTO workout_logs (username, plan) VALUES (?, ?)";

        try (Connection conn = DBConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, planName);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
    }

    private void setupWorkoutPlans() {
        workoutDetails.put("Beginner Full Body", """
            - 10 min warm-up (jumping jacks, high knees)
            - 3 sets of squats (15 reps)
            - 3 sets of push-ups (10 reps)
            - 3 sets of lunges (10 per leg)
            - 30 sec plank hold
            - Cool-down stretches
            """);

        workoutDetails.put("Intermediate Split", """
            Day 1: Chest & Triceps
            - Bench press (4 sets x 10 reps)
            - Dumbbell flys
            - Triceps dips

            Day 2: Back & Biceps
            - Pull-ups
            - Barbell rows
            - Dumbbell curls

            Alternate with core and leg days.
            """);

        workoutDetails.put("Advanced Strength", """
            - Deadlift (5x5)
            - Squats (5x5)
            - Overhead press
            - Barbell bench press
            - Pull-ups / weighted
            - Rest days between heavy lifts
            """);

        workoutDetails.put("Cardio Focus", """
            - 30 min HIIT treadmill
            - 15 min cycling
            - Jump rope (3 rounds)
            - Burpees + mountain climbers
            - Cool-down with yoga stretches
            """);
    }
}
