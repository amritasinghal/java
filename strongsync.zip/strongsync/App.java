package strongsync;

public class App {
    public static void main(String[] args) {
        // Start with the login/register screen
        javax.swing.SwingUtilities.invokeLater(() -> new LoginGUI());
    }
}