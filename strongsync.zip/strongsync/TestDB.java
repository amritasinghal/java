package strongsync;

import java.sql.Connection;

public class TestDB {
    public static void main(String[] args) {
        Connection conn = DBConnector.getConnection();
        if (conn != null) {
            System.out.println("✅ Database connected!");
        } else {
            System.out.println("❌ Connection failed.");
        }
    }
}
