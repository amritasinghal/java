package strongsync;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BMICalculatorGUI extends JFrame {
    public BMICalculatorGUI(String username) {
        setTitle("BMI Calculator - " + username);
        setSize(450, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Main panel
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        JLabel heightLabel = new JLabel("Height (cm):");
        JTextField heightField = new JTextField();
        JLabel weightLabel = new JLabel("Weight (kg):");
        JTextField weightField = new JTextField();
        JButton calculateButton = new JButton("Calculate");
        JLabel resultLabel = new JLabel("BMI: ");
        resultLabel.setFont(new Font("Arial", Font.BOLD, 14));

        inputPanel.add(heightLabel);
        inputPanel.add(heightField);
        inputPanel.add(weightLabel);
        inputPanel.add(weightField);
        inputPanel.add(calculateButton);
        inputPanel.add(resultLabel);

        // Suggestion panel
        JTextArea suggestionArea = new JTextArea(4, 30);
        suggestionArea.setLineWrap(true);
        suggestionArea.setWrapStyleWord(true);
        suggestionArea.setEditable(false);
        suggestionArea.setFont(new Font("Arial", Font.ITALIC, 13));
        JScrollPane scrollPane = new JScrollPane(suggestionArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Health Suggestion"));

        // Back button
        JButton backButton = new JButton("Back to Dashboard");
        backButton.addActionListener(e -> {
            dispose();
            new DashboardGUI(username);
        });

        // Calculate action
        calculateButton.addActionListener(e -> {
            try {
                double height = Double.parseDouble(heightField.getText()) / 100;
                double weight = Double.parseDouble(weightField.getText());
                double bmi = weight / (height * height);

                String category = getBMICategory(bmi);
                String suggestion = getBMISuggestion(category);

                resultLabel.setText(String.format("BMI: %.1f (%s)", bmi, category));
                resultLabel.setForeground(getCategoryColor(category));
                suggestionArea.setText(suggestion);

                // Save to database
                saveBMIRecord(username, height * 100, weight, bmi, category);

            } catch (NumberFormatException ex) {
                resultLabel.setText("Please enter valid numbers");
                resultLabel.setForeground(Color.RED);
                suggestionArea.setText("");
            }
        });

        // Add components
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(backButton, BorderLayout.SOUTH);
        setVisible(true);
    }

    private String getBMICategory(double bmi) {
        if (bmi < 18.5) return "Underweight";
        else if (bmi < 25) return "Normal";
        else if (bmi < 30) return "Overweight";
        else return "Obese";
    }

    private String getBMISuggestion(String category) {
        switch (category) {
            case "Underweight":
                return "You are underweight. Consider a balanced diet rich in proteins, healthy fats, and regular strength training.";
            case "Normal":
                return "Great job! Maintain your healthy lifestyle with regular exercise and a balanced diet.";
            case "Overweight":
                return "You're slightly overweight. Focus on cardio workouts and monitor your calorie intake.";
            case "Obese":
                return "It’s important to consult a doctor. Begin with light exercise and a medically guided nutrition plan.";
            default:
                return "";
        }
    }

    private Color getCategoryColor(String category) {
        switch (category) {
            case "Underweight": return new Color(70, 130, 180);     // Light Blue
            case "Normal":      return new Color(34, 139, 34);      // Green
            case "Overweight":  return new Color(255, 140, 0);      // Orange
            case "Obese":       return new Color(220, 20, 60);      // Red
            default:            return Color.BLACK;
        }
    }

    private void saveBMIRecord(String username, double height, double weight, double bmi, String category) {
        String sql = "INSERT INTO bmi_data (username, height_cm, weight_kg, bmi_value, category) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setDouble(2, height);
            stmt.setDouble(3, weight);
            stmt.setDouble(4, bmi);
            stmt.setString(5, category);
            stmt.executeUpdate();

            System.out.println("✅ BMI record saved for " + username);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
