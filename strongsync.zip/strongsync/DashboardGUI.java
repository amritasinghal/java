package strongsync;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DashboardGUI extends JFrame {
    public DashboardGUI(String username) {
        setTitle("StrongSync - " + username);
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Header
        JPanel header = new JPanel();
        header.add(new JLabel("Welcome, " + username + "!"));
        add(header, BorderLayout.NORTH);

        // Main buttons
        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JButton bmiButton = new JButton("BMI Calculator");
        JButton workoutButton = new JButton("Workout Plans");
        JButton dietButton = new JButton("Diet Tracker");

        styleButton(bmiButton);
        styleButton(workoutButton);
        styleButton(dietButton);

        buttonPanel.add(bmiButton);
        buttonPanel.add(workoutButton);
        buttonPanel.add(dietButton);
        add(buttonPanel, BorderLayout.CENTER);

        // Button actions
        bmiButton.addActionListener(e -> {
            dispose();
            new BMICalculatorGUI(username);
        });

        workoutButton.addActionListener(e -> {
            dispose();
            new WorkoutPlanGUI(username);
        });

        dietButton.addActionListener(e -> {
            dispose();
            new DietTrackerGUI(username);
        });

        setVisible(true);
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
    }
}