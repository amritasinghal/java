package strongsync;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class DietTrackerGUI extends JFrame {
    private final DefaultTableModel tableModel;
    private final JLabel totalCaloriesLabel;
    private final ArrayList<Integer> caloriesList = new ArrayList<>();

    public DietTrackerGUI(String username) {
        setTitle("Diet Tracker - " + username);
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Header
        JLabel header = new JLabel("Track Your Daily Meals");
        header.setFont(new Font("Arial", Font.BOLD, 18));
        header.setHorizontalAlignment(SwingConstants.CENTER);
        add(header, BorderLayout.NORTH);

        // Table for meals
        String[] columnNames = {"Meal", "Calories", "Notes"};
        tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Input panel
        JPanel inputPanel = new JPanel(new GridLayout(2, 4, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        JTextField mealField = new JTextField();
        JTextField calField = new JTextField();
        JTextField noteField = new JTextField();
        JButton addButton = new JButton("Add Meal");

        inputPanel.add(new JLabel("Meal:"));
        inputPanel.add(mealField);
        inputPanel.add(new JLabel("Calories:"));
        inputPanel.add(calField);
        inputPanel.add(new JLabel("Notes:"));
        inputPanel.add(noteField);
        inputPanel.add(new JLabel("")); // empty cell
        inputPanel.add(addButton);

        add(inputPanel, BorderLayout.NORTH);

        // Bottom panel with calorie total and actions
        JPanel bottomPanel = new JPanel(new BorderLayout());

        totalCaloriesLabel = new JLabel("Total Calories: 0");
        totalCaloriesLabel.setFont(new Font("Arial", Font.BOLD, 14));
        bottomPanel.add(totalCaloriesLabel, BorderLayout.WEST);

        JButton clearButton = new JButton("Clear All");
        JButton backButton = new JButton("Back to Dashboard");

        clearButton.addActionListener(e -> {
            tableModel.setRowCount(0);
            caloriesList.clear();
            updateTotalCalories();
        });

        backButton.addActionListener(e -> {
            dispose();
            new DashboardGUI(username);
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(clearButton);
        buttonPanel.add(backButton);
        bottomPanel.add(buttonPanel, BorderLayout.EAST);

        add(bottomPanel, BorderLayout.SOUTH);

        // Add meal action
        addButton.addActionListener(e -> {
            String meal = mealField.getText().trim();
            String calText = calField.getText().trim();
            String note = noteField.getText().trim();

            if (meal.isEmpty() || calText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter meal and calories.");
                return;
            }

            try {
                int calories = Integer.parseInt(calText);
                caloriesList.add(calories);
                tableModel.addRow(new Object[]{meal, calories, note});
                updateTotalCalories();
                mealField.setText("");
                calField.setText("");
                noteField.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Calories must be a number.");
            }
        });

        setVisible(true);
    }

    private void updateTotalCalories() {
        int total = caloriesList.stream().mapToInt(Integer::intValue).sum();
        totalCaloriesLabel.setText("Total Calories: " + total);
    }
}
